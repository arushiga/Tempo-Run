//
//  TempoApp.swift
//  Tempo
//
//  Created by Kristine Huang on 4/5/26.
//

import SwiftUI

@main
struct TempoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
